package com.example.demo;
//import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Configuration;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Bean;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.JstlView;
//import org.springframework.web.reactive.result.view.ViewResolver;
//import java.util.List;
//import java.util.*;

@EnableWebMvc
@Configuration
@ComponentScan("com.example.demo") 
public class WebConfig // implements WebMvcConfigurer
{  

    
    @Bean
	public  InternalResourceViewResolver internalResourceViewResolver() 
	{
	    InternalResourceViewResolver bean = new InternalResourceViewResolver();
	    bean.setViewClass(JstlView.class);
        bean.setPrefix("/WEB-INF/biews/");
        bean.setSuffix(".jsp");
	    return bean;
    }

    /*@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**")
          .addResourceLocations("/resources/"); 
    }
    */

}