package com.example.demo;
/*
import org.springframework.context.annotation.Configuration;
import java.util.Collections;
import java.util.Collection;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
//import MongoDB.Driver.Core.Configuration.ConnectionString;
import com.mongodb.MongoClientSettings;
*/

public class MongoConfig {

   /* @Bean
    public MongoClient mongo() {
        ConnectionString connectionString = new ConnectionString("mongodb://localhost:27017/test");
        MongoClientSettings mongoClientSettings = MongoClientSettings.builder()
          .applyConnectionString(connectionString)
          .build();
        
        return MongoClients.create(mongoClientSettings);
    }

    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongo(), "test");
    }
 
*/

}